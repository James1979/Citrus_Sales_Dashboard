# 🟠 Citrus Sales Dashboard

## 📊 Project Overview

This dashboard analyzes weekly and monthly sales performance of citrus products across:
- **Product Type**
- **Region**
- **Customer Channel**

It enables Kings River's sales leaders to monitor revenue, optimize product mix, and respond to regional trends.

---

## 📂 Project Structure

```
Citrus_Sales_Dashboard/
│
├── data/
│   └── citrus_sales_data.csv
│
├── report/
│   └── Citrus_Sales_Report.pbix
│
└── README.md
```

---

## 📈 Power BI Report Layout

**Top Row: KPI Cards**
- Total Revenue
- Units Sold
- Average Price per Unit (Revenue / Units Sold)

**Middle Section**
- 📉 Line Chart: Revenue by Week
- 📊 Bar Chart: Units Sold by Product

**Bottom Section**
- 🗺️ Map: Revenue by Region
- 🥧 Pie Chart: Revenue by Channel

---

## 🧠 Business Value

Helps Kings River:
- Monitor revenue trends by week and region
- Understand product-level performance
- Compare retail vs. wholesale channels
- Align product mix with seasonal and regional demand

---

## 🛠 Tools Used

- Power BI
- DAX (Time Intelligence: YTD, MOM)
- CSV for structured input
